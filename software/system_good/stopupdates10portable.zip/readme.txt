
StopUpdates10 - Totally Disable Windows 7-11 Updates and Upgrades!
https://greatis.com/stopupdates10
or 
https://stopupdates10.com
Take control of Windows 11 updates and upgrades
Main:
- Windows Updates 100% Bulletproof Hard Block (with Double Protection)
- Windows Updates Soft Block - Pause Updates until 11/11/2099 with the ability to update Windows Defender and Windows Store Apps.

Features: 
1) Stops Windows updates.
2) Stops forced upgrades.
3) Stops annoying upgrade notifications.
4) Restore updates with one click. 
5) Pauses updates.
6) Disables Windows 7-8 'End of support' and 'End of Service' notifications.

Freeware (commercial usage is allowed.)

Changelog

Version 4.7.2024.0423:
- Added the notification panel with a progress bar and stop button to control the cleaning up of temporary Windows update files.
- Improved the speed of deleting the temporary files. 
- Added the hiding the system tray "restart update" icon.
- Added Turkish translation.
Known issue with Autocad software:
Some people experience a delay in starting Autocad software with disabled Windows updates. The issue may be caused by disabling the BITS service. As a workaround, you can uncheck BITS in the blocked services list.

Version 4.6.2024.0403
- Compatibility with Windows 11 2023H2.
- Fixed issue with not working Pause Updates.
- Fixed issues with Updates Guard.

Version 4.5.2023.0523
- Added blocking services: PushToInstall, Bits, DoSvc.
The PushToInstall service automatically restores the Windows Update service after installing update KB5026372. 
- Fixed bugs with user-defined services in the Updates Guard service.

Version 4.0.2023.0306
- Fixed the bug preventing using the "Stay on the Current Feature Update" feature for 20H2 and the newest builds. 
- Added the Simplified Chinese translation. 

Version 3.9.2023.0214
- Automatically delete downloaded updates pending to install (SoftwareDistribution/Download).
- Fixed the security issues in the Updates Guard service.

Version 3.8.2022.1129
- Compatibility with the latest Windows 11 (22H2) and Windows 10.
- Improved installation StopUpdates Premium.
- Fixed bug in the StopUpdates Premium.
- Updated language translations.

Version 3.7.2022.712
- New: blocking Windows 11 upgrade full-screen ads.
- Compatibility with the latest Windows 11 (21H2) and Windows 10.

Version 3.6.2021.705
- Compatibility with Windows 11 (Build:22000) and Windows 10 (21H1).
- New: block feature updates using TargetReleaseVersionInfo Windows policy.
- Fixed the bug in the SU10Guard service: "A timeout was reached while waiting for the SU10Guard service to connect". 
   Now SU10Guard will start its starts as delayed. 
   But pay attention that the status of StopUpdates Guard in the main program will be shown as "disabled" until the service starts. 
   Usually, the service starts within two minutes after boot.
- Command-line option: "/disable" is available only in the Premium version because of using it by malware. 
- New Premium option: Hide Promo. It hides the promo offers.

Version 3.5.115
- Compatibility with Windows 10 (2104).
- Added a new process to block: UPFC.EXE, related to WaaSMedic.
- Redesigned.

Version 3.01.101
- Added Turkish translation.
- Updated translations: Brazilian Portuguese, Czech, Greek, Hungarian, Italian, Japan, Polish, Spanish, Ukrainian.
- Fixed small bugs.

Version 3.0.100
- New feature: Double Protection Service Settings (via registry permissions and using Updates Guard).
- Disable Additional Services (selected by a user).
- Disabled service: USOSVC.
- New: Premium version.
- Pause or resume updates using a command line.

Version 2.5.70
- Blocked new process: WaasMedicAgent.exe.
- Removed blocking for dismHost.exe because of issues with the normal work of DISM.

Version 2.5.61
- Added Catalan translation.
- Updated Japanese translation.
- Fixed small bugs.

Version 2.5.60
- Added Traditional Chinese translation.
- Fixed small bugs.

Version 2.5.59
- Added "/defender" option for checking Windows Defender updates from the command line interface.
- Added Polish translation.

Version 2.5.58
- Fixed bug with Windows Defender updates.
- Added Bulgarian translation.

Version 2.5.57
- Updates Japanese, Italian, Greek and Korean translations.

Version 2.5.56
- Fixed small bugs.
- Updates Spanish, Ukrainian, Brazilian, Czech and Hungarian translations.

Version 2.5.55
- New feature: Pause updates until up to 2099.
- New feature: Disable Windows 7-8 'End of support', 'End of Service' notifications, Get Windows 10 (GWX).
- New Feature: Update Windows Defender signatures.

Version 2.0.52:
- Disable Windows 7 End of Service screen during startup (KB4493132)
- Updated Spashish Translation.

Version 2.0.51:
- Added Ukrainian, Arabic translations.
- Updated Czech, Portuguese Brazilian.
- Fixed a small bug.
 
Version 2.0.50:
- Added blocking of Windows Update Medic service (WaasMedicSvc).
Windows Update Medic can reactivate the update service.
StopUpdates10 blocks "WaasMedicSvc" automatically using the Updates Guard service.
Windows service manager cannot disable "WaasMedicSvc."
StopUpdates10 can do it using direct registry change.
- Fixed bug with incorrect checking of the service state.
- Fixed bug with uninstalling.
- New website: 
  https://greatis.com/stopupdates10


Windows uses
Updates Guard.
Updates Guard is a system service working in the background.
It polls an activity of the Windows update service.
If Updates Guard detects the change in the Windows Update service (Wuauserv"), 
it will disable it.
Updates Guard is started automatically.
It takes a small number of system resources.

Why Updates Guard?
Unfortunately, Microsoft uses an aggressive way to install every new build.
The old tricks do not work.
Updates Guard will always help to stop updates.

Question: 
I don't want to have an additional service on my system.
Answer:  
Open StopUpdates10, File, Settings menu. 
Choose "Only for Power Users."
Uncheck the box "Updates Guard is Active."
Click OK.

Question: 
How to change the polling interval?
Answer:  
Create a text file with the name "SU10Guard.ini".
Put this into the file:
[Settings]
CheckProcessSeconds=10

Question: 
How to remove the Updates Guard manually?
Answer:  
Launch "uninstall-guard.bat."

Disclaimer of Warranty

THIS SOFTWARE AND THE ACCOMPANYING FILES ARE SOLD "AS IS" 
AND WITHOUT WARRANTIES AS TO PERFORMANCE OR MERCHANTABILITY 
OR ANY OTHER WARRANTIES, WHETHER EXPRESSED OR IMPLIED. 

Usage:
1) Open StopUpdates10.exe.
2) Click 'Stop Windows Updates!'.

To undo changes:
Click 'Restore Windows Updates' button.

Command line:
- disable Windows updates:
StopUpdates10.exe /disable

- enable Windows updates:
StopUpdates10.exe /restore

- reboot PC:
StopUpdates10.exe /reboot

- shutdown PC:
StopUpdates10.exe /shutdown

- update Windows Defender:
StopUpdates10.exe /defender

- pause updates
StopUpdates10.exe /pause
This will pause updates until  11.11.2099
You can set your date:
StopUpdates10.exe /pause yyyymmdd
yyyymmdd - year, month, day
Example:
StopUpdates10.exe /pause 20301231

- resume updates
StopUpdates10.exe /resume

More information:
http://greatis.com/stopupdates10

Comments or questions:
http://greatis.com/support

Recommended:
RegRun Security Suite:
http://www.regrun.com
(24 tools system tools in the Platinum Edition)
UnHackMe:
http://www.unhackme.com
(First bootwatch antirootkit and anti malware)

StopUpdates10 (c) Copyright Greatis Software 