If you are not an English native speaker and need to translate the software to your own language, you can translate the language file in the installation files. Note that the file named english.ini is the default file and don't modify it. 

Follow the below instruction to learn how to translate the language to your needed language:

1. Copy english.ini and rename it as you like: xxx.ini
2. Modify the language content in this xxx.ini. Note that you can only modify the content after the "=", for example, STR_OK=OK, you can modify it as STR_OK=XX. 
3. When the modification is done, copy xxx.ini to the folder where you copied the file from. 
4. Launch Driver Talent and go to Settings page >language >select the language file xxx.ini. 
5. Exit Driver Talent and re-start it, you would find that the software shows with your own language. 
